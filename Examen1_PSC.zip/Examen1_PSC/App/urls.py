from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('dieciseis_bits/', views.dieciseis, name='dieciseis_bits'),
    path('treinta_y_dos_bits/', views.treinta_y_dos, name='treinta_y_dos_bits'),
    path('sesenta_y_cuatro_bits/', views.sesenta_y_cuatro, name='sesenta_y_cuatro_bits'),
    path('ochenta_bits/', views.ochenta, name='ochenta_bits')
]
