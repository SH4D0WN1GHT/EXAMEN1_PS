from django.shortcuts import render

def index(request):
    return render(request, 'base.html')

def dieciseis(request):
    return render(request, '16bits.html')

def treinta_y_dos(request):
    return render(request, '32bits.html')

def sesenta_y_cuatro(request):
    return render(request, '64bits.html')

def ochenta(request):
    return render(request, '80bits.html')