document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('boton').addEventListener('click', function() {
        let numeroOriginal = parseFloat(document.getElementById('numero').value);
        
        if (isNaN(numeroOriginal)) {
            alert("Introduzca un número válido, entero o de punto flotante");
        } else {
            // Conversión a binario
            let numeroAbs = Math.abs(numeroOriginal); // Valor absoluto para que no exista problema en el exp :v
            let binario = numeroAbs.toString(2);
            let [parteEntera, parteFraccionaria] = binario.split('.');
            parteFraccionaria = parteFraccionaria || '';

            // Normalización
            let normalizado = normalizacion(parteEntera, parteFraccionaria);
            
            // Obtención del signo
            let signo = (numeroOriginal >= 0) ? 0 : 1;

            // Obtención del exponente
            let exponente = obtencionExponente(parteEntera);
            let expoBinario = exponente.toString(2).padStart(4, '0');

            // Obtención de la mantissa
            let mantissa = new Array(23).fill(0);
            let fraccLength = fracc.length;
            for (let i = 0; i < fraccLength && i < 23; i++) {
                mantissa[i] = parseInt(fracc[i], 10);
            }
            // Convertir la mantissa a cadena
            let mantissaBin = mantissa.join('');

            // Resultado
            let dir = [signo.toString()].concat(exponente.toString(2).padStart(8, '0').split('')).concat(mantissaBin.padEnd(23, '0').split(''));

            // Convertir `dir` a hexadecimal
            let hexadecimal = '';
            for (let i = 0; i < dir.length; i += 4) {
                let bloqueDe4Bits = dir.slice(i, i + 4).join(''); // Extraer cada bloque de 4 bits
                let valorDecimal = parseInt(bloqueDe4Bits, 2);         // Convertir a decimal
                let valorHexadecimal = valorDecimal.toString(16).toUpperCase(); // Convertir a hexadecimal
                hexadecimal += valorHexadecimal.padStart(1, '0');
            }

            // Convertir a little endian
            let littleEndian = hexadecimal.match(/.{2}/g).reverse().join('');

            // Mostrar resultados
            document.getElementById('binario').textContent = binario;
            document.getElementById('normalizado').textContent = normalizado;
            document.getElementById('signo').textContent = signo;
            document.getElementById('exponente').textContent = exponente.toString(16);
            document.getElementById('expo-binario').textContent = expoBinario;
            document.getElementById('mantissa').textContent = mantissaBin.padEnd(23, '0');
            document.getElementById('direccion').textContent = littleEndian;
        }
    });

    let fracc;
    // Función para normalizar el número binario
    function normalizacion(parteEntera, parteFraccionaria) {
        let desplazamiento = parteEntera.length - 1;
        fracc = parteEntera.slice(1) + parteFraccionaria;
        let norm = `1.${fracc} * 2^${desplazamiento}`;
        return norm;
    }
    
    // Función para obtener el exponente basado en la parte entera
    function obtencionExponente(parteEntera) {
        let desplazamiento = parteEntera.length - 1;
        let base = 127;
        return base + desplazamiento;
    }
});
